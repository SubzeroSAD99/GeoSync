import styled from "styled-components";
import { media } from "../../utils/Media.styles.mjs";
import { motion } from "framer-motion";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const StyledMenu = styled(motion.nav)({
  display: "flex",
  flexDirection: "column",
  justifyContent: "space-between",
  backgroundColor: "var(--main-color)",
  boxShadow: "0px 0px 8px 0px var(--main-color)",
  color: "var(--text-color2)",
  width: "250px",
  height: "100%",
  fontSize: "1.1rem",
  alignSelf: "start",
  justifySelf: "start",
  paddingRight: "5px",

  ...media({
    zIndex: 1000,
    transformOrigin: "top right",
    left: "inherit",
    top: "28px",
    right: "10px",
    height: "max-content",
    minHeight: "200px",
    borderRadius: "10px",
    borderTopRightRadius: "0px",
  }),
});

const StyledList = styled.ul`
  position: sticky;
  top: 0px;
  left: 0px;
`;

const StyledFontAwesome = styled(FontAwesomeIcon)({
  fontSize: "1.4rem",
  cursor: "pointer",
});

export { StyledMenu, StyledList, StyledFontAwesome };
