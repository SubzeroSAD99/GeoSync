import styled from "styled-components";
import { media } from "../../utils/Media.styles.mjs";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const StyledMenu = styled.nav`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  background-color: var(--main-color);
  box-shadow: 0px 0px 8px 0px var(--main-color);
  color: var(--text-color2);
  width: 250px;
  height: 100%;
  font-size: 1.1rem;
  align-self: start;
  justify-self: start;
  padding-right: 5px;
  transition: width 0.3s ease;

  ${media(`
    z-index: 1000;
    transform-origin: top right;
    left: inherit;
    top: 28px;
    right: 10px;
    height: max-content;
    min-height: 200px;
    border-radius: 10px;
    border-top-right-radius: 0px;
  `)}
`;

const StyledList = styled.ul`
  position: sticky;
  top: 0px;
  left: 0px;
  overflow: hidden;
`;

const ItemShowHide = styled.li`
  display: grid;
  grid-template-columns: 1fr;
  width: 100%;
  justify-items: end;
  align-items: center;
  padding: 8px 0px;

  & > button {
    box-shadow: none !important;
    background-color: transparent;
  }

  & > button > svg {
    font-size: 1.3rem !important;
  }
`;

const BtnTheme = styled.button`
  position: sticky;
  bottom: 0px;
  left: 0px;
  padding-bottom: 5px;
  padding-left: 5px;
  width: max-content;
  box-shadow: none !important;
  background-color: transparent;
`;

const StyledFontAwesome = styled(FontAwesomeIcon)`
  font-size: 1.4rem;
  cursor: pointer;
`;

export { StyledMenu, StyledList, ItemShowHide, BtnTheme, StyledFontAwesome };
