import React, { useEffect, useState } from "react";
import Calendar from "../Calendar/Calendar";
import {
  InfoContainer,
  StyledButton,
  StyledFontAwesome,
  StyledTable,
  StyledTd,
  StyledTh,
  TableContainer,
} from "./ScheduleService.styled.mjs";
import { faCheck, faSquareCheck } from "@fortawesome/free-solid-svg-icons";
import api from "../../../utils/api.mjs";
import { toast } from "react-toastify";

const ScheduleServices = () => {
  const [eventsByTopographer, setEventsByTopographer] = useState({});
  const [selected, setSelected] = useState({ day: "", topographer: "" });
  const [topographers, setTopographers] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const response = await api.post("/employee/getTopographers");

        if (response.data) setTopographers(response.data.topographers);
      } catch (err) {
        const msg = err?.response?.data?.msg;

        toast.error(msg);
      }
    })();
  }, []);

  const setEventsFor = (topographer) => (newEvents) => {
    setEventsByTopographer((prev) => ({
      ...prev,
      [topographer.id]: newEvents,
    }));
  };

  const confirmService = async (id) => {
    try {
      const response = await api.post("/service/confirm", { id });

      if (response.data) {
        setEventsByTopographer((prev) => {
          const { topographer, day } = selected;
          const dayEvents = prev[topographer]?.[day] || [];
          const updated = dayEvents.map((item) =>
            item.id === id ? { ...item, confirmed: true } : item
          );
          return {
            ...prev,
            [topographer]: {
              ...prev[topographer],
              [day]: updated,
            },
          };
        });
        if (response.data?.warn) toast.warn(response.data.msg);
        else toast.success(response.data.msg);
      }
    } catch (err) {
      const msg = err?.response?.data?.msg;

      toast.error(msg);
    }
  };

  return (
    <section style={{ gap: "40px" }}>
      {selected.day ? (
        <InfoContainer
          onClick={() => setSelected({ day: "", topographer: "" })}
        >
          <TableContainer onClick={(e) => e.stopPropagation()}>
            <StyledTable>
              <thead>
                <tr>
                  <StyledTh>Tipo de Serviço</StyledTh>
                  <StyledTh>Propietário</StyledTh>
                  <StyledTh>Contratante</StyledTh>
                  <StyledTh>Telefone</StyledTh>
                  <StyledTh>Municipio / Local</StyledTh>
                  <StyledTh>Horario</StyledTh>
                  <StyledTh>Obs</StyledTh>
                  <StyledTh>Confirmar</StyledTh>
                </tr>
              </thead>
              <tbody>
                {eventsByTopographer[selected.topographer][selected.day].map(
                  ({
                    id,
                    serviceType,
                    owner,
                    contractor,
                    contractorNumber,
                    ownerNumber,
                    municipaly,
                    measurementHour,
                    internalObs,
                    confirmed,
                  }) => (
                    <tr key={id}>
                      <StyledTd>{serviceType}</StyledTd>
                      <StyledTd>{owner}</StyledTd>
                      <StyledTd>{contractor}</StyledTd>
                      <StyledTd>{contractorNumber || ownerNumber}</StyledTd>
                      <StyledTd>{municipaly}</StyledTd>
                      <StyledTd>{measurementHour}</StyledTd>
                      <StyledTd>{internalObs}</StyledTd>
                      <StyledTd>
                        {!confirmed ? (
                          <StyledButton
                            onClick={() => {
                              confirmService(id);
                            }}
                          >
                            <StyledFontAwesome icon={faSquareCheck} />
                          </StyledButton>
                        ) : (
                          <StyledFontAwesome icon={faCheck} />
                        )}
                      </StyledTd>
                    </tr>
                  )
                )}
              </tbody>
            </StyledTable>
          </TableContainer>
        </InfoContainer>
      ) : (
        <></>
      )}
      {topographers.map((topographer) => (
        <Calendar
          key={topographer.id}
          topographer={topographer}
          events={eventsByTopographer[topographer.id] || {}}
          setEvents={setEventsFor(topographer)}
          setViewScheduleDay={(day) =>
            setSelected({ day, topographer: topographer.id })
          }
        />
      ))}
    </section>
  );
};

export default ScheduleServices;
