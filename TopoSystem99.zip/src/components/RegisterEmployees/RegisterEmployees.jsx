import React from "react";
import SelectItem from "../SelectItem/SelectItem";
import FormInputItem from "../FormInputItem/FormInputItem";
import {
  StyledButton,
  StyledForm,
  Title,
} from "./RegisterEmployees.styled.mjs";

const RegisterEmployees = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <section>
      <Title>Cadastro de Funcionario</Title>
      <StyledForm>
        <SelectItem
          options={["ADMINISTRADOR"]}
          title="Cargo"
          placeholder="FUNCIONARIO"
          name="position"
        />

        <FormInputItem id="cpf" type="text" label="CPF" />
        <FormInputItem id="name" type="text" label="Nome" />
        <FormInputItem id="email" type="email" label="Email" />
        <FormInputItem
          id="password"
          type="password"
          label="Senha"
          eyeIcon={true}
        />

        <StyledButton type="submit" onClick={handleSubmit}>
          Cadastrar
        </StyledButton>
      </StyledForm>
    </section>
  );
};

export default RegisterEmployees;
