import React from "react";
import Home from "../components/Home/Home.jsx";

const HomePage = () => {
  return <Home />;
};

export default HomePage;
