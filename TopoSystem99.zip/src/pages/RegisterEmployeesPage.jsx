import React from "react";
import RegisterEmployees from "../components/RegisterEmployees/RegisterEmployees";

const RegisterEmployeesPage = () => {
  return <RegisterEmployees />;
};

export default RegisterEmployeesPage;
