import React from "react";
import Login from "../../components/Employees/Login/Login.jsx";

const LoginPage = () => {
  return <Login />;
};

export default LoginPage;
