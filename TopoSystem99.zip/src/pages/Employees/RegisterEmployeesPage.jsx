import React from "react";
import RegisterEmployees from "../../components/Employees/RegisterEmployees/RegisterEmployees";

const RegisterEmployeesPage = () => {
  return <RegisterEmployees />;
};

export default RegisterEmployeesPage;
