import React from "react";
import Employees from "../../components/Employees/Employees";

const EmployeesPage = () => {
  return <Employees />;
};

export default EmployeesPage;
