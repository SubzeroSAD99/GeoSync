import React from "react";
import RegisterMunicipalities from "../../components/Municipalities/RegisterMunicipalities/RegisterMunicipalities";

const RegisterMunicipalitiesPage = () => {
  return <RegisterMunicipalities />;
};

export default RegisterMunicipalitiesPage;
