import React from "react";
import Municipalities from "../../components/Municipalities/Municipalities";

const MunicipalitiesPage = () => {
  return <Municipalities />;
};

export default MunicipalitiesPage;
