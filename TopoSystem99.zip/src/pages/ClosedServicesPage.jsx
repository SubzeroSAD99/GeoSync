import React from "react";
import ClosedServices from "../components/ClosedServices/ClosedServices";

const ClosedServicesPage = () => {
  return <ClosedServices />;
};

export default ClosedServicesPage;
