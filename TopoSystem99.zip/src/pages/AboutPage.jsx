import React from "react";

const AboutPage = () => {
  return <div>lopes</div>;
};

export default AboutPage;
