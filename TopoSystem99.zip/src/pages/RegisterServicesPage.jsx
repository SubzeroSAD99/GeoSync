import React from "react";
import RegisterServices from "../components/RegisterServices/RegisterServices";

const RegisterServicesPage = () => {
  return <RegisterServices />;
};

export default RegisterServicesPage;
