import React from "react";
import NotFound from "../components/NotFound/NotFound.jsx";

const NotFoundPage = () => {
  return <NotFound />;
};

export default NotFoundPage;
