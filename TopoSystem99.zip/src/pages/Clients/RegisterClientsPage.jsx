import React from "react";
import RegisterClients from "../../components/Clients/RegisterClients/RegisterClients";

const RegisterClientsPage = () => {
  return <RegisterClients />;
};

export default RegisterClientsPage;
