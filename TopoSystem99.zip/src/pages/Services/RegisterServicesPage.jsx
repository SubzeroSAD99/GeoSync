import React from "react";
import RegisterServices from "../../components/Services/RegisterServices/RegisterServices";

const RegisterServicesPage = () => {
  return <RegisterServices />;
};

export default RegisterServicesPage;
