import React from "react";
import ScheduleServices from "../../components/Services/ScheduleServices/ScheduleServices";

const ScheduleServicesPage = () => {
  return <ScheduleServices />;
};

export default ScheduleServicesPage;
