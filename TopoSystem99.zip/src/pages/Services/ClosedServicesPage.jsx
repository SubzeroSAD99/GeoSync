import React from "react";
import ClosedServices from "../../components/Services/ClosedServices/ClosedServices";

const ClosedServicesPage = () => {
  return <ClosedServices />;
};

export default ClosedServicesPage;
