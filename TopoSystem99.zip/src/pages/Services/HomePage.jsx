import React from "react";
import OpenedServices from "../../components/Services/OpenedServices/OpenedServices.jsx";

const HomePage = () => {
  return <OpenedServices />;
};

export default HomePage;
