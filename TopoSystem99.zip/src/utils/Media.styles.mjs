const media = (styles) => ({
  "@media (max-width: 768px)": styles,
});

export { media };
